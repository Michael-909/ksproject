<?php

return [

    'login_failed' => 'No match for E-Mail Address and/or Password.',


];
