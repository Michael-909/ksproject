<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header card-header-info card-header-icon">
                        <div class="card-icon">
                            <i class="fas fa-user"></i>
                        </div>
                        <h4 class="card-title">Sub Admin Privileges</h4>
                    </div>
                    <div class="card-body">
                        <form id="mainForm" method="post" action="" class="form-horizontal">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                            <div class="row">
                                <div class="col-md-12 text-right">
                                    <a href="<?php echo e(route('admin-account')); ?>" class="btn btn-sm">Back to list</a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <table class="table table-striped table-no-bordered table-hover dataTable">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th>Role Name</th>
                                                <th>Description</th>
                                                <th>Privilege</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $index = 1;
                                                foreach ($roles as $role) {
                                            ?>
                                            <tr>
                                                <td><?php echo e($index); ?></td>
                                                <td><?php echo e($role->name); ?></td>
                                                <td><?php echo e($role->description); ?></td>
                                                <td>
                                                    <select class="custom-select role-level" data-role="<?php echo e($role->id); ?>">
                                                        <option></option>
                                                        <option value="<?php echo e(config('ticketing.account_role_level.view')); ?>" <?php echo e(($role->level == config('ticketing.account_role_level.view')) ? 'selected' : ''); ?>>View</option>
                                                        <option value="<?php echo e(config('ticketing.account_role_level.change')); ?>" <?php echo e(($role->level == config('ticketing.account_role_level.change')) ? 'selected' : ''); ?>>Change</option>
                                                    </select>
                                                </td>
                                            </tr>
                                            <?php
                                                    $index++;
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-profile">
                    <div class="card-avatar">
                        <a href="#">
                            <img class="img" src="photo/<?php echo e($user->id); ?>" alt="">
                        </a>
                    </div>
                    <div class="card-body">
                        <h6 class="card-category text-gray"><?php echo e($user->email); ?></h6>
                        <h4 class="card-title"><?php echo e($user->uid); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
        $('form#mainForm select.role-level').on('change', function(){
            var role_id = $(this).attr('data-role');
            var level = $(this).val();
            $.ajax({
                url: 'role/save',
                type: 'POST',
                data: {
                    '_token': $('form#mainForm input[name="_token"]').val(),
                    'user_id': $('form#mainForm input[name="user_id"]').val(),
                    'role_id': role_id,
                    'level': level
                },
                dataType: 'json',
                success: function(result) {
                    
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin', ['activePage' => 'account', 'titlePage' => __('Account')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebRoot\Melaka\ticketing\resources\views/pages/admin/account/role.blade.php ENDPATH**/ ?>