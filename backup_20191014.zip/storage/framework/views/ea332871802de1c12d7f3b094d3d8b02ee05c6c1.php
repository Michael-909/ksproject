
<form id="seatsForm" method="post" autocomplete="off" class="form-horizontal">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="price_id" value="<?php echo e(empty($price->id) ? 0 : $price->id); ?>">
    <div class="row">
        <div class="col-12">
            <div class="form-group">
                <input type="text" class="form-control-plaintext" readonly value="<?php echo e(config('ticketing.ticket_type')[$price->ticket_type]); ?>">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">

            <div class="" style="max-height: 300px; overflow: auto;">
                <table class="table table-striped table-hover table-sm">
                    <tbody>
                        <?php foreach ($seats as $seat) { ?>
                        <tr>
                            <td class="text-right">
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox" value="" checked>
                                        <span class="form-check-sign">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <?php echo e($seat->name); ?>

                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</form>
<?php /**PATH F:\WebRoot\Melaka\ticketing\resources\views/pages/admin/event/price_seats.blade.php ENDPATH**/ ?>