<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <form id="mainForm" method="post" action="" autocomplete="off">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id">
                <input type="hidden" name="event_id">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header card-header-info card-header-icon">
                                <div class="card-icon">
                                    <i class="fas fa-film"></i>
                                </div>
                                <h4 class="card-title">Events</h4>
                            </div>
                            <div class="card-body">
                                <div class="dataTables_wrapper">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="dataTables_filter">
                                                <label>
                                                    <input type="text" name="keyword" class="form-control form-control-sm" value="<?php echo e(empty($params['keyword'])?'':$params['keyword']); ?>" placeholder="Search">
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-sm-6 text-right">
                                            <div class="toolbar">
                                                <a href="#" class="btn btn-success btn-sm btn-edit" data-id="0">Add event</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table class="table table-striped table-no-bordered table-hover dataTable">
                                                <thead>
                                                    <tr>
                                                        <th>Image</th>
                                                        <th>Title</th>
                                                        <th>Duration</th>
                                                        <th>Hall</th>
                                                        <th>Period</th>
                                                        <th>Active</th>
                                                        <th class="text-right">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php if(count($events) == 0): ?>
                                                    <tr>
                                                        <td colspan="7">
                                                            &nbsp;
                                                        </td>
                                                    </tr>
                                                <?php else: ?>
                                                    <?php
                                                        $index = ($params['page'] - 1) * $params['rows'] + 1;
                                                        foreach ($events as $event) {
                                                    ?>
                                                    <tr>
                                                        <td>
                                                            <div class="rounded-circle img-circle">
                                                                <img src="event/image/<?php echo e($event->id); ?>" alt="" class="event-image">
                                                            </div>
                                                        </td>
                                                        <td><?php echo e($event->title); ?></td>
                                                        <td><?php echo e($event->duration); ?></td>
                                                        <td><?php echo e($event->venue_name); ?></td>
                                                        <td><?php echo e($event->from_date . ' ~ ' . $event->to_date); ?></td>
                                                        <td>
                                                            <?php if($event->status == config('ticketing.available.yes')): ?>
                                                            <i class="fa fa-check"></i>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="td-actions text-right">
                                                            <a href="#" class="btn btn-info btn-schedule" data-event-id="<?php echo e($event->id); ?>"><i class="far fa-clock"></i></a>
                                                            <a href="#" class="btn btn-warning btn-price" data-event-id="<?php echo e($event->id); ?>"><i class="fas fa-dollar-sign"></i></a>
                                                            <a href="#" class="btn btn-success btn-edit" data-id="<?php echo e($event->id); ?>"><i class="fas fa-pencil-alt"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                            $index++;
                                                        }
                                                    ?>
                                                <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <?php echo $__env->make('layout.admin_pagination', ['params' => $params, 'records' => $events], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('js/pages/pagination.js')); ?>"></script>
<script>
    $(document).ready(function() {
        $('.btn-edit').on('click', function(){
            var id = $(this).attr('data-id');
            $('form#mainForm input[name="id"]').val(id);
            $('form#mainForm').attr('action', 'event/edit');
            $('form#mainForm').submit();
        });
        $('form#mainForm input[name="keyword"]').on('change', function() {
            goPage(1);
        });
        $('.btn-price').on('click', function(){
            var event_id = $(this).attr('data-event-id');
            $('form#mainForm input[name="event_id"]').val(event_id);
            $('form#mainForm').attr('action', 'event/price');
            $('form#mainForm').submit();
        });
        $('.btn-schedule').on('click', function(){
            var event_id = $(this).attr('data-event-id');
            $('form#mainForm input[name="event_id"]').val(event_id);
            $('form#mainForm').attr('action', 'show/schedule');
            $('form#mainForm').submit();
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin', ['activePage' => 'event', 'titlePage' => __('Shows')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebRoot\Melaka\ticketing\resources\views/pages/admin/event/list.blade.php ENDPATH**/ ?>