<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <form method="post" enctype="multipart/form-data" action="" autocomplete="off" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-header card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">home</i>
                            </div>
                            <h4 class="card-title">Hall 1</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 text-right">
                                    <a href="<?php echo e(route('admin-hall')); ?>" class="btn btn-sm">Back to list</a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-2 col-md-3">
                                    <!--
                                        color-classes: "nav-pills-primary", "nav-pills-info", "nav-pills-success", "nav-pills-warning","nav-pills-danger"
                                    -->
                                    <ul class="nav nav-pills nav-pills-success nav-pills-icons flex-column" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" data-toggle="tab" href="#seatsmap" role="tablist">
                                                <i class="material-icons">airline_seat_recline_normal</i> Seats Map
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" data-toggle="tab" href="#sectors" role="tablist">
                                                <i class="material-icons">grid_on</i> Sectors
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="seatsmap">
                                            <img src="<?php echo e(asset('img/hall.jpg')); ?>" alt="" style="width: 100%; height: auto;">
                                        </div>
                                        <div class="tab-pane" id="sectors">
                                            <div class="row">
                                                <div class="col-12">
                                            <table class="table table-striped table-no-bordered table-hover dataTable">
                                                <thead>
                                                    <tr>
                                                        <th>No</th>
                                                        <th>Name</th>
                                                        <th>Floor</th>
                                                        <th>Available</th>
                                                        <th class="text-right">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>1</td>
                                                        <td>A1</td>
                                                        <td>0</td>
                                                        <td><i class="fa fa-check"></i></td>
                                                        <td class="td-actions text-right">
                                                            <a href="#" class="btn btn-success"><i class="material-icons">edit</i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>2</td>
                                                        <td>A2</td>
                                                        <td>0</td>
                                                        <td><i class="fa fa-check"></i></td>
                                                        <td class="td-actions text-right">
                                                            <a href="#" class="btn btn-success"><i class="material-icons">edit</i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>3</td>
                                                        <td>A3</td>
                                                        <td>0</td>
                                                        <td><i class="fa fa-check"></i></td>
                                                        <td class="td-actions text-right">
                                                            <a href="#" class="btn btn-success"><i class="material-icons">edit</i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>4</td>
                                                        <td>A4</td>
                                                        <td>0</td>
                                                        <td><i class="fa fa-check"></i></td>
                                                        <td class="td-actions text-right">
                                                            <a href="#" class="btn btn-success"><i class="material-icons">edit</i></a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>5</td>
                                                        <td>N1</td>
                                                        <td>1</td>
                                                        <td><i class="fa fa-check"></i></td>
                                                        <td class="td-actions text-right">
                                                            <a href="#" class="btn btn-success"><i class="material-icons">edit</i></a>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>

                                            
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
        $('#seatsmap').click(function (e) {
            var pos = $(this).offset();
            //alert((e.pageX) + ' , ' + (e.pageY));
            //alert((pos.top) + ' , ' + (pos.left));
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin', ['activePage' => 'hall', 'titlePage' => __('Halls')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebRoot\Melaka\ticketing\resources\views/pages/admin/hall/seat.blade.php ENDPATH**/ ?>