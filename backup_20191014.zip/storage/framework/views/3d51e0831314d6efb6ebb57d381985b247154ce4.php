<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            // Javascript method's body can be found in assets/js/demos.js

        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.agent', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/winnef94/public_html/ticketing/resources/views/pages/agent/dashboard.blade.php ENDPATH**/ ?>