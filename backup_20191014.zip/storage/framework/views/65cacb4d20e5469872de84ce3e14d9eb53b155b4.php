<div class="sidebar">
    <div class="logo text-center">
        <a href="<?php echo e(route('home')); ?>" class="logo-normal">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="">
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('agent-dashboard')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'user' ? ' active' : ''); ?>">
                <a class="nav-link" href="#">
                    <i class="material-icons">account_box</i>
                    <p><?php echo e(__('Users')); ?></p>
                </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'booking' ? ' active' : ''); ?>">
                <a class="nav-link" href="#">
                    <i class="material-icons">assignment</i>
                    <p><?php echo e(__('Booking')); ?></p>
                </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'notification' ? ' active' : ''); ?>">
                <a class="nav-link" href="#">
                    <i class="material-icons">notifications</i>
                    <p><?php echo e(__('Notifications')); ?></p>
                </a>
            </li>
        </ul>
    </div>
</div><?php /**PATH /home/winnef94/public_html/ticketing/resources/views/layout/agent_sidebar.blade.php ENDPATH**/ ?>