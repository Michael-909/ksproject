<footer class="footer">
    <div class="container-fluid">
        <div class="copyright float-right">
            <script>document.write(new Date().getFullYear())</script>
        </div>
    </div>
</footer><?php /**PATH /home/winnef94/public_html/ticketing/resources/views/layout/footer.blade.php ENDPATH**/ ?>