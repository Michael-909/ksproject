<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin - Melaka Ticket Booking</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>">

    <!-- Fonts and icons -->
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/fontawesome-all.min.css')); ?>">
      
    <!-- CSS Files -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.custom.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
</head>
<body>
    <div class="wrapper admin-wrapper">
        <?php echo $__env->make('layout.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-panel">
            <?php echo $__env->make('layout.admin_auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <script src="<?php echo e(asset('js/vendor/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/vendor/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/sweetalert2.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/jquery.bootstrap-wizard.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/bootstrap-selectpicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/bootstrap-tagsinput.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/jasny-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/jquery-jvectormap.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/nouislider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/arrive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/chartist.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor/bootstrap-notify.js')); ?>"></script>

    <script src="<?php echo e(asset('js/pages/material.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/pages/application.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('js'); ?>

</body>
</html><?php /**PATH F:\WebRoot\Melaka\ticketing\resources\views/layout/admin.blade.php ENDPATH**/ ?>