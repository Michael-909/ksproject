<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <form id="mainForm" method="post" enctype="multipart/form-data" action="" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="event_id" value="<?php echo e($event->id); ?>">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header card-header-info card-header-icon">
                                <div class="card-icon">
                                    <i class="fas fa-film"></i>
                                </div>
                                <h4 class="card-title"><?php echo e(__('Shows')); ?></h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-12 text-right">
                                        <a href="#" class="btn btn-success btn-sm btn-edit" data-id="0">Add</a>
                                        <a href="<?php echo e(route('admin-event-list')); ?>" class="btn btn-sm">Back to list</a>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped table-no-bordered table-hover dataTable">
                                            <thead>
                                                <tr>
                                                    <th>No.</th>
                                                    <th>Showtime</th>
                                                    <th>Venue</th>
                                                    <th>Active</th>
                                                    <th class="text-right">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php if(count($shows) == 0): ?>
                                                <tr>
                                                    <td colspan="5">
                                                        &nbsp;
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <?php
                                                    $index = 1;
                                                    foreach ($shows as $show) {
                                                        $showtime = date_create_from_format('Y-m-d H:i:s', $show->date_time);
                                                        $showtime = date_format($showtime, 'Y-m-d h:i a');
                                                ?>
                                                <tr>
                                                    <td><?php echo e($index); ?></td>
                                                    <td><?php echo e($showtime); ?></td>
                                                    <td><?php echo e($show->venue_name); ?></td>
                                                    <td>
                                                        <?php if($show->status == config('ticketing.available.yes')): ?>
                                                        <i class="fa fa-check"></i>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="td-actions text-right">
                                                        <a href="#" class="btn btn-success btn-edit" data-id="<?php echo e($show->id); ?>"><i class="fas fa-pencil-alt"></i></a>
                                                    </td>
                                                </tr>
                                                <?php
                                                        $index++;
                                                    }
                                                ?>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-header card-header-icon">
                                <h4 class="card-title">Tickets</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-12">
                                        <?php
                                            $arr_price = [];
                                            foreach ($price_list as $price_ticket) {
                                                $arr_price[$price_ticket->ticket_type] = $price_ticket;
                                            }
                                            foreach (config('ticketing.ticket_type') as $key => $value) {
                                                if (array_key_exists($value, $arr_price)) {
                                                    if ($arr_price[$value]->status == config('ticketing.available.yes')) {
                                        ?>
                                        <div class="row">
                                            <label class="col-sm-6 col-form-label"><?php echo e($key); ?></label>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <input class="form-control" type="text" value="<?php echo e($arr_price[$value]->price); ?>" disabled>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                                    }
                                                }
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card card-profile">
                            <div class="card-header">
                                <img class="img" src="image/<?php echo e($event->id); ?>" alt="" style="max-width: 250px;">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title"><?php echo e($event->title); ?></h4>
                                <h6 class="card-category text-gray">Duration: <?php echo e($event->duration); ?></h6>
                                <h6 class="card-category text-gray">Period: <?php echo e($event->from_date . ' ~ ' . $event->to_date); ?></h6>
                                <h6 class="card-category text-gray">Show Time: <?php echo e($event->time); ?></h6>
                                <i class="fa fa-clock-o"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title card-title">Show</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-success btn-save">Save</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    $(document).ready(function() {
        
        $('.btn-edit').on('click', function(){
            var event_id = $('form#mainForm input[name="event_id"]').val();
            var id = $(this).attr('data-id');
            $.ajax({
                url: 'edit',
                type: 'POST',
                data: {
                    '_token': $('form#mainForm input[name="_token"]').val(),
                    'event_id': event_id,
                    'id': id
                },
                success: function(result) {
                    $('#editModal .modal-body').html(result);
                    $('#editModal').modal('show');
                }
            });
        });
        
        $('.btn-save').on('click', function(){
            if ($('form#editForm input[name="date_time"]').val().trim().length == 0) {
                return;
            }
            var status = 0;
            if ($('form#editForm input[name="status"]').is(':checked')) {
                status = 1;
            }
            $.ajax({
                url: 'save',
                type: 'POST',
                data: {
                    '_token': $('form#editForm input[name="_token"]').val(),
                    'id': $('form#editForm input[name="id"]').val(),
                    'event_id': $('form#editForm input[name="event_id"]').val(),
                    'venue_id': $('form#editForm select[name="venue_id"]').val(),
                    'date_time': $('form#editForm input[name="date_time"]').val(),
                    'status': status
                },
                dataType : 'json',
                success: function(result) {
                    $('#mainForm').submit();
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin', ['activePage' => 'show', 'titlePage' => __('Shows')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/winnef94/public_html/ticketing/resources/views/pages/admin/show/list.blade.php ENDPATH**/ ?>