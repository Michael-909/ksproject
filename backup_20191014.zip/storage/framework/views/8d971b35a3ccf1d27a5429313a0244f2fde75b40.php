<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <form method="post" enctype="multipart/form-data" action="" autocomplete="off" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-header card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">home</i>
                            </div>
                            <h4 class="card-title">Add new hall</h4>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12 text-right">
                                    <button type="submit" class="btn btn-success btn-sm">Save</button>
                                    <a href="<?php echo e(route('admin-hall')); ?>" class="btn btn-sm">Back to list</a>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Name</label>
                                <div class="col-sm-7">
                                    <div class="form-group">
                                        <input class="form-control" name="name" type="text" placeholder="Name" value="" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Active</label>
                                <div class="col-sm-7">
                                    <div class="form-group">
                                        <div class="togglebutton">
                                            <label>
                                                <input type="checkbox" name="is_active" checked>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <label class="col-sm-2 col-form-label">Seats Map</label>
                                <div class="col-sm-10">
                                    <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                                        <div>
                                            <span class="btn btn-file">
                                                <span class="fileinput-new">Select image</span>
                                                <span class="fileinput-exists">Change</span>
                                                <input type="file" name="photo" id = "input-picture">
                                            </span>
                                            <a href="#pablo" class="btn btn-danger fileinput-exists" data-dismiss="fileinput">
                                                <i class="fa fa-times"></i> Remove
                                            </a>
                                        </div>
                                        <div class="fileinput-new">
                                            <img src="<?php echo e(asset('img/image_placeholder.jpg')); ?>" alt="..." style="max-width: 100%;">
                                        </div>
                                        <div class="fileinput-preview fileinput-exists"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin', ['activePage' => 'hall', 'titlePage' => __('Halls')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebRoot\Melaka\ticketing\resources\views/pages/admin/hall/add.blade.php ENDPATH**/ ?>