<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header card-header-icon">
                        <div class="card-icon">
                            <i class="material-icons">perm_identity</i>
                        </div>
                        <h4 class="card-title">Setting available payment type</h4>
                    </div>
                    <div class="card-body">
                        <form id="mainForm" method="post" action="" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                            <div class="row">
                                <div class="col-md-12 text-right">
                                    <a href="<?php echo e(route('admin-agent')); ?>" class="btn btn-sm">Back to list</a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <table class="table table-striped table-no-bordered table-hover dataTable">
                                        <thead>
                                            <tr>
                                                <th>No.</th>
                                                <th>Payment Type</th>
                                                <th>Available</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $available = [];
                                                foreach ($payment_types as $payment_type) {
                                                    $available[] = $payment_type->payment_type;
                                                }
                                                $index = 1;
                                                foreach (config('ticketing.payment_type') as $key => $value) {
                                            ?>
                                            <tr>
                                                <td><?php echo e($index); ?></td>
                                                <td><?php echo e($key); ?></td>
                                                <td>
                                                    <div class="form-check form-check-inline">
                                                        <label class="form-check-label">
                                                            <input class="form-check-input payment-type" type="checkbox" value="<?php echo e($value); ?>" <?php echo e(in_array($value, $available) ? 'checked' : ''); ?>>
                                                            <span class="form-check-sign">
                                                                <span class="check"></span>
                                                            </span>
                                                        </label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php
                                                    $index++;
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-profile">
                    <div class="card-avatar">
                        <a href="#">
                            <img class="img" src="photo/<?php echo e($user->id); ?>" alt="">
                        </a>
                    </div>
                    <div class="card-body">
                        <h6 class="card-category text-gray"><?php echo e($user->email); ?></h6>
                        <h4 class="card-title"><?php echo e($user->uid); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/pages/admin/agent_payment_type.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin', ['activePage' => 'agent', 'titlePage' => __('Agent')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebRoot\Melaka\ticketing\resources\views/pages/admin/agent/payment_type.blade.php ENDPATH**/ ?>