<div class="sidebar">
    <div class="logo text-center">
        <a href="<?php echo e(route('home')); ?>" class="logo-normal">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="">
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin-dashboard')); ?>">
                    <i class="fas fa-th-large"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="nav-item <?php echo e(($activePage == 'account' || $activePage == 'agent' || $activePage == 'counter') ? ' active' : ''); ?>">
                <a class="nav-link" data-toggle="collapse" href="#user-management">
                    <i class="fas fa-users"></i>
                    <p><?php echo e(__('Users')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse <?php echo e(($activePage == 'account' || $activePage == 'agent' || $activePage == 'counter') ? ' show' : ''); ?>" id="user-management">
                    <ul class="nav">
                        <li class="nav-item<?php echo e($activePage == 'account' ? ' active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('admin-account')); ?>">
                                <i class="fa fa-angle-right"></i>
                                <span class="sidebar-normal"><?php echo e(__('Accounts')); ?> </span>
                            </a>
                        </li>
                        <li class="nav-item<?php echo e($activePage == 'agent' ? ' active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('admin-agent')); ?>">
                                <i class="fa fa-angle-right"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Agents')); ?> </span>
                            </a>
                        </li>
                        <li class="nav-item<?php echo e($activePage == 'counter' ? ' active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('admin-counter')); ?>">
                                <i class="fa fa-angle-right"></i>
                                <span class="sidebar-normal"> <?php echo e(__('Counters')); ?> </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item<?php echo e($activePage == 'booking' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin-booking')); ?>">
                    <i class="far fa-clipboard"></i>
                    <p><?php echo e(__('Booking')); ?></p>
                </a>
            </li>
            <li class="nav-item<?php echo e(($activePage == 'event' || $activePage == 'show') ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin-event-list')); ?>">
                    <i class="fas fa-film"></i>
                    <p><?php echo e(__('Shows')); ?></p>
                </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'hall' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin-hall')); ?>">
                    <i class="far fa-life-ring"></i>
                    <p><?php echo e(__('Halls')); ?></p>
                </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'promotion' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin-promotion-package')); ?>">
                    <i class="fas fa-gift"></i>
                    <p><?php echo e(__('Promotion')); ?></p>
                </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'options' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin-options')); ?>">
                    <i class="fas fa-wrench"></i>
                    <p><?php echo e(__('Options')); ?></p>
                </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'notification' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin-notifications')); ?>">
                    <i class="fas fa-bell"></i>
                    <p><?php echo e(__('Notifications')); ?></p>
                </a>
            </li>
            <li class="nav-item<?php echo e($activePage == 'report' ? ' active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('admin-report')); ?>">
                    <i class="fas fa-file-alt"></i>
                    <p><?php echo e(__('Report')); ?></p>
                </a>
            </li>
        </ul>
    </div>
</div><?php /**PATH F:\WebRoot\Melaka\ticketing\resources\views/layout/admin_sidebar.blade.php ENDPATH**/ ?>