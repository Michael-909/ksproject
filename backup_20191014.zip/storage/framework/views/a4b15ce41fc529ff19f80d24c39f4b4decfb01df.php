<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">camera</i>
                            </div>
                            <h4 class="card-title"><?php echo e(__('Events')); ?></h4>
                        </div>
                        <div class="card-body">
                            <div class="toolbar text-right">
                                <a href="<?php echo e(route('admin-event-edit')); ?>" class="btn btn-sm">Add event</a>
                            </div>
                            <div class="dataTables_wrapper" id="eventtable" style="display: none;">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">
                                        <div class="dataTables_length">
                                            <label>
                                                Show 
                                                <select name="rows" class="custom-select custom-select-sm form-control form-control-sm">
                                                    <option value="10">10</option>
                                                    <option value="25">25</option>
                                                    <option value="50">50</option>
                                                    <option value="-1">All</option>
                                                </select>
                                                entries
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <div class="dataTables_filter">
                                            <label>
                                                <input type="text" name="keywords" class="form-control form-control-sm" placeholder="Search users">
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table class="table table-striped table-no-bordered table-hover dataTable">
                                            <thead>
                                                <tr>
                                                    <th>Image</th>
                                                    <th>Title</th>
                                                    <th>Duration</th>
                                                    <th>Active</th>
                                                    <th class="text-right">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <div>
                                                            <img src="<?php echo e(asset('img/shows/1.png')); ?>" alt="" style="width: 60px;">
                                                        </div>
                                                    </td>
                                                    <td>RASA MELAKA PREVIEW (MAY, 2019)</td>
                                                    <td>60</td>
                                                    <td><i class="fa fa-check"></i></td>
                                                    <td class="td-actions text-right">
                                                        <a href="<?php echo e(route('admin-show-list')); ?>" class="btn btn-warning"><i class="material-icons">local_see</i></a>
                                                        <a href="<?php echo e(route('admin-event-edit')); ?>" class="btn btn-success"><i class="material-icons">edit</i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div>
                                                            <img src="<?php echo e(asset('img/shows/2.jpg')); ?>" alt="" style="width: 60px;">
                                                        </div>
                                                    </td>
                                                    <td>RASA MELAKA (AUGUST, 2019)</td>
                                                    <td>75</td>
                                                    <td><i class="fa fa-check"></i></td>
                                                    <td class="td-actions text-right">
                                                        <a href="<?php echo e(route('admin-show-list')); ?>" class="btn btn-warning"><i class="material-icons">local_see</i></a>
                                                        <a href="<?php echo e(route('admin-event-edit')); ?>" class="btn btn-success"><i class="material-icons">edit</i></a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12 col-md-5">
                                        <div class="dataTables_info" role="status" aria-live="polite">
                                            Showing 1 to 2 of 2 entries
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-7">
                                        <div class="dataTables_paginate paging_full_numbers">
                                            <ul class="pagination">
                                                <li class="paginate_button page-item first disabled" id="usertables_first">
                                                    <a href="#" aria-controls="usertables" data-dt-idx="0" tabindex="0" class="page-link">First</a>
                                                </li>
                                                <li class="paginate_button page-item previous disabled" id="usertables_previous">
                                                    <a href="#" aria-controls="usertables" data-dt-idx="1" tabindex="0" class="page-link">Prev</a>
                                                </li>
                                                <li class="paginate_button page-item active">
                                                    <a href="#" aria-controls="usertables" data-dt-idx="2" tabindex="0" class="page-link">1</a>
                                                </li>
                                                <li class="paginate_button page-item next disabled" id="usertables_next">
                                                    <a href="#" aria-controls="usertables" data-dt-idx="3" tabindex="0" class="page-link">Next</a>
                                                </li>
                                                <li class="paginate_button page-item last disabled" id="usertables_last">
                                                    <a href="#" aria-controls="usertables" data-dt-idx="4" tabindex="0" class="page-link">Last</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            

            $('#eventtable').fadeIn(1100);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin', ['activePage' => 'event', 'titlePage' => __('Shows')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\WebRoot\Melaka\ticketing\resources\views/pages/admin/event/search.blade.php ENDPATH**/ ?>